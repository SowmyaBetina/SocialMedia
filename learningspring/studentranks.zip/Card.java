package com.prodapt.learning;

public class Card {
	private String name;
	private int score;
	private int rank;
	
	
	public Card(String name, int score) {
		this.name = name;
		this.score = score;
		
		this.rank = 1;
	}
	public String getName() {
        return name;
    }
	
    public int getScore() {
        return score;
    }
    public void setScore(int score) {
        this.score = score;
    }

    
    public int getRank() {
    	return rank;
    }
    public void setRank(int rank) {
    	this.rank = rank;
    }
}
