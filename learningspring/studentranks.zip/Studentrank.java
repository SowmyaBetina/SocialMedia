package com.prodapt.learning;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import lombok.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/student")
public class Studentrank {
    private ArrayList<Card> cardList = new ArrayList<>();

    @GetMapping
    public String show(Model model) {
        Collections.sort(cardList, Comparator.comparingInt(Card::getScore).reversed());
        
        model.addAttribute("cardlist", cardList);
        return "studentrank";
    }

    @PostMapping
    public void processstudent(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String name = req.getParameter("name");
        //int rank = Integer.parseInt("id");
        //int id = Integer.parseInt(req.getParameter("id"));
        int score = Integer.parseInt(req.getParameter("score"));
        String buttonid1 = req.getParameter("add");

        if (buttonid1 != null && buttonid1.equals("add")) {
            cardList.add(new Card(name, score));
            Collections.sort(cardList, Comparator.comparingInt(Card::getScore).reversed());
            assignRanks();
        }
        
        resp.sendRedirect("/student");
    }

    private void assignRanks() {
        int rank = 1;
        for (int i = 0; i < cardList.size(); i++) {
            Card card = cardList.get(i);
            if (i > 0 && card.getScore() < cardList.get(i - 1).getScore()) {
                rank++;
            }
            card.setRank(rank);
        }
    }
    @PostMapping("/delete")
    public void deleteStudent(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int idToDelete = Integer.parseInt(req.getParameter("id"));

        cardList.removeIf(card -> card.getRank() == idToDelete);
        assignRanks();

        resp.sendRedirect("/student");
    }
    @PostMapping("/edit")
    public void editStudent(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        int idToedit = Integer.parseInt(req.getParameter("id"));
        int newval = Integer.parseInt(req.getParameter("value"));
        for (Card card : cardList) {
            if (card.getRank() == idToedit) {
                card.setScore(newval);
                break;             
                }
        }

        Collections.sort(cardList, Comparator.comparingInt(Card::getScore).reversed());
        	
        
        
        assignRanks();

        resp.sendRedirect("/student");
    }

   
}
